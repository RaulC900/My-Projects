#pragma once

#include <Laboratoare/Tema1/Tema1.h>
