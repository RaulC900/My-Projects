#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "compare.h"

typedef struct node {
	char *word;
	int priority;
	struct node *next;
} Node;

int isEmpty(Node **n)
{
	return (*n) == NULL;
}

int Insert(Node **n, char *w, int p)
{
	Node *start = (*n);
	Node *aux;

	aux = (Node *)malloc(sizeof(Node));
	if (aux) {

		aux->word = (char *)malloc((strlen(w)+1) * sizeof(char));
		if (!aux->word)
			return 12;
		aux->word = w;
		aux->priority = p;
		aux->next = NULL;
	} else if (!aux)
		return 12;
	if (isEmpty(n)) {
		*n = (Node *)malloc(sizeof(Node));
		if (*n) {

			(*n)->word = (char *)
					malloc((strlen(w)+1) * sizeof(char));
			if (!(*n)->word)

				return 12;
			(*n)->word = w;
			(*n)->priority = p;
			(*n)->next = NULL;
		} else if (!(*n))

			return 12;
	} else {

		if (compare((*n)->priority, p) <= 0) {

			aux->next = *n;
			*n = aux;
		} else {

			while (start->next != NULL
				 && (compare(start->next->priority, p) >= 0))
				start = start->next;
			aux->next = start->next;
			start->next = aux;
		}
	}
	return 0;
}

char *top(Node **n)
{
	if (isEmpty(n))
		return "\n";
	else
		return (*n)->word;
}

void pop(Node **n)
{
	if (!isEmpty(n)) {
		Node *aux = *n;
		(*n) = (*n)->next;
		free(aux->word);
		free(aux);
	}
}

int ReadFile(Node *n, char *file)
{
	int j;
	int code = 0;
	FILE *pFile;
	char *buffer;
	char *text;
	char *word;
	char *text1;

	pFile = fopen(file, "r");
	if (pFile != NULL) {
		buffer = (char *)malloc(20000 * sizeof(char));
		if (!buffer)
			return 12;
		while (fgets(buffer, 20000, pFile) != NULL) {
			word = (char *)malloc(20000 * sizeof(char));
			if (!word)
				return 12;
			text = (char *)malloc(20000 * sizeof(char));
			if (!text)
				return 12;
			text = strtok(buffer, " ");
			if (!strcmp(text, "insert")) {
				text1 = (char *)malloc(20000 * sizeof(char));
				if (!text1)
					return 12;
				text = strtok(NULL, " ");
				strcpy(word, text);
				text1 = strtok(NULL, " ");
				if (text1 != NULL) {
					j = atoi(text1);
					if (strtok(NULL, " ") == NULL) {
						code = Insert(&n, word, j);
						if (code == 12)
							return 12;
					}
				}
			} else if (!strcmp(text, "top\n")) {
				if (strtok(NULL, " ") == NULL)
					printf("%s\n", top(&n));
			} else if (!strcmp(text, "pop\n")) {
				if (strtok(NULL, " ") == NULL)
					pop(&n);
			}
			free(text);
			free(word);
		}
		fclose(pFile);
		free(buffer);
	}
	return 1;
}

int ReadStdin(Node *n)
{
	int j;
	int code = 0;
	char *buffer;
	char *text;
	char *word;

	buffer = (char *)malloc(20000 * sizeof(char));
	if (!buffer)
		return 12;
	while (fgets(buffer, 20000, stdin) != NULL) {
		word = (char *)malloc(20000 * sizeof(char));
		if (!word)
			return 12;
		text = (char *)malloc(20000 * sizeof(char));
		if (!text)
			return 12;
		text = strtok(buffer, " ");
		if (!strcmp(text, "insert")) {
			text = strtok(NULL, " ");
			strcpy(word, text);
			text = strtok(NULL, " ");
			j = atoi(text);
			if (strtok(NULL, " ") == NULL) {
				code = Insert(&n, word, j);
				if (code == 12)
					return 12;
			}
		} else if (!strcmp(text, "top\n")) {
			printf("%s\n", top(&n));
		} else if (!strcmp(text, "pop\n")) {
			pop(&n);
		}
	}
	return 0;
}

int main(int argc, char *argv[])
{
	Node *n = NULL;
	int i;
	int j, k;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			j = ReadFile(n, argv[i]);
			if (j == 12)
				return 12;
		}
	} else {
		k = ReadStdin(n);
			if (k == 12)
				return 12;
	}
}
