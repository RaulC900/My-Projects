#!/bin/bash

#
# Tema1 Test Suite
#
# 2012-2018, Operating Systems
#

# ----------------- General declarations and util functions ------------------ #

# Enable/disable exiting when program fails.
EXIT_IF_FAIL=0
# Enable/disable debug (1/0).
DEBUG_=0
# checkpatch.pl URL
CHECKPATCH_URL="https://raw.githubusercontent.com/torvalds/linux/master/scripts/checkpatch.pl"
COMMON_IGNORE_FLAGS="
	SPLIT_STRING,SSCANF_TO_KSTRTO,NEW_TYPEDEFS,VOLATILE,INLINE,USE_FUNC,AVOID_EXTERNS,CONST_STRUCT,SPDX_LICENSE_TAG"
LIN_IGNORE_FLAGS="$COMMON_IGNORE_FLAGS"
WIN_IGNORE_FLAGS="$COMMON_IGNORE_FLAGS,DOS_LINE_ENDINGS"

if [ $(uname -s) == "Linux" ]; then
	CHECKPATCH_IGNORE_FLAGS=$LIN_IGNORE_FLAGS
else
	CHECKPATCH_IGNORE_FLAGS=$WIN_IGNORE_FLAGS
fi

CHECKPATCH_ARGS="
	--no-tree
	--no-summary
	--terse
	--ignore $CHECKPATCH_IGNORE_FLAGS
	--show-types"

DEBUG()
{
	if test "x$DEBUG_" = "x1"; then
		$@ 1>&2
	fi
}

print_header()
{
	header="${1}"
	header_len=${#header}
	printf "\n"
	if [ $header_len -lt 71 ]; then
		padding=$(((71 - $header_len) / 2))
		for ((i = 0; i < $padding; i++)); do
			printf " "
		done
	fi
	printf "= %s =\n\n" "${header}"
}


test_do_fail()
{
	printf "failed  [ 0/%02d]\n" "$max_points"
	if test "x$EXIT_IF_FAIL" = "x1"; then
		exit 1
	fi
}

test_do_pass()
{
	printf "passed  [%02d/%02d]\n" "$1" "$max_points"
}


DF=${DF:--BEbwu}

# Compares to files and prints the first 10
# lines if the files differ
function compare()
{
	diff $DF $1 $2 > __result
	ret=$?
	if [ $ret != 0 ] ; then
		echo "$1 vs $2:"
		cat __result | head -n 10
	fi
	rm -f __result
	return $ret
}

memory_test()
{
    DEBUG echo "MEM TEST"

    res=$1
    memcheck_description="$description - memcheck"
    printf "%02d) %s" "$test_index" "$memcheck_description"

	for ((i = 0; i < 56 - ${#memcheck_description}; i++)); do
		printf "."
	done

    if test $res -eq 0; then
        test_do_pass "$mem_points"
    else
        test_do_fail "$mem_poits"
    fi
}

basic_test()
{
	DEBUG echo "TEST: $@"
	$@
	res=$?
	printf "%02d) %s" "$test_index" "$description"

	for ((i = 0; i < 56 - ${#description}; i++)); do
		printf "."
	done

	if test $res -eq 0; then
        test_do_pass "$points"
        return 0
	else
        test_do_fail "$points"
        return -1
	fi
}

check_source()
{
	# check to see if we have checkpatch
	check_patch=$(which checkpatch.pl 2> /dev/null)
	if ! [ -x "$check_patch" ]; then
		echo "'checkpatch.pl' tool not found on your system."\
			"Skipping source check..."
		echo "Please download 'checkpatch.pl' from '$CHECKPATCH_URL'"\
			"and install it in your \$PATH."
		echo
		return
	fi

	# try to find sources in the current directory
	src_files="$(find "${SRC_DIR:-.}" -type f -iregex \
		'.*\.\(c\|h\|cpp\|hpp\|cc\|hh\|cxx\|hxx\)')"
	if [ -z "$src_files" ]; then
		read -t 60 -e -p 'Please provide path to your sources: ' SRC_DIR
		if [ "$?" -ne "0" -o -z "$SRC_DIR" ]; then
			echo -e "No path provided! Skipping source check...\n"
			return
		fi
		if ! [ -e "$SRC_DIR" ]; then
			echo -e "File or directory '$SRC_DIR' does not exist. " \
				"Skipping source check...\n"
			return
		fi
		src_files="$(find "$SRC_DIR" -type f -iregex \
			'.*\.\(c\|h\|cpp\|hpp\|cc\|hh\|cxx\|hxx\)')"
		if [ -z "$src_files" ]; then
			echo -e "No sources found in '$SRC_DIR'. " \
				"Skipping source check...\n"
			return
		fi
	fi
	# now we have sources in $SRC_DIR or .
	OUT=$(find "${SRC_DIR:-.}" -type f -iregex \
		'.*\.\(c\|h\|cpp\|hpp\|cc\|hh\|cxx\|hxx\)' | \
		xargs $check_patch $CHECKPATCH_ARGS -f 2>&1 | tail -n +2 | \
		sort -u -t":" -k4,4  | head -n 20)
	echo "$OUT"
}

check_comp_c()
{
    echo "Running check_comp_c"

    # try to find sources in the current directory
    src_files="$(find "${SRC_DIR:-.}" -type f -iregex \
        '.*\.\(c\|h\|cpp\|hpp\|cc\|hh\|cxx\|hxx\)')"
    if [ -z "$src_files" ]; then
        read -t 60 -e -p 'Please provide path to your sources: ' SRC_DIR
        if [ "$?" -ne "0" -o -z "$SRC_DIR" ]; then
            echo -e "No path provided! Skipping source check...\n"
            return
        fi
        if ! [ -e "$SRC_DIR" ]; then
            echo -e "File or directory '$SRC_DIR' does not exist. " \
                "Skipping source check...\n"
            return
        fi
        src_files="$(find "$SRC_DIR" -type f -iregex \
            '.*\.\(c\|h\|cpp\|hpp\|cc\|hh\|cxx\|hxx\)')"
        if [ -z "$src_files" ]; then
            echo -e "No sources found in '$SRC_DIR'. " \
                "Skipping source check...\n"
            return
        fi
    fi

	OUT=$(find "${SRC_DIR:-.}" -iname compare.c)
	echo $OUT
}

test_coding_style()
{
	check_source
	[ -n "$src_files" -a -z "$OUT" ]
	basic_test [ $? -eq 0 ]
}

test_compare_c()
{
	check_comp_c
	[ -n "$src_files" -a -z "$OUT" ]
	basic_test [ $? -eq 0 ]
}

check_tests()
{
	# we need to have the test_fun_array defined
	if [ -z "$test_fun_array" ]; then
		echo "test_fun_array is not defined - don't know what to run" 1>&2
		exit 1
	fi

	# max_points
	if [ -z "$max_points" ]; then
		echo "max_points is not defined - don't the total number of points" 1>&2
		exit 1
	fi
}

run_tests()
{
	if test $# -ne 1; then
		echo "Usage: $0 test_number | init | cleanup" 1>&2
		exit 1
	fi

	test_index=$1

	if test $test_index == "init"; then
		init_world
		exit 0
	fi

	if test $test_index == "cleanup"; then
		cleanup_world
		exit 0
	fi

	if test $test_index == "check"; then
		check_source
		exit 0
	fi

	arr_index=$(($test_index * 4))
	last_test=$((${#test_fun_array[@]} / 4))
	description=${test_fun_array[$(($arr_index + 1))]}

	points=${test_fun_array[$(($arr_index + 2))]}
	mem_points=${test_fun_array[$(($arr_index + 3))]}

	if test "$test_index" -gt "$last_test" -o "$arr_index" -lt 0; then
		echo "Error: Test index is out range (1 < test_index <= $last_test)." 1>&2
		exit 1
	fi

	# Run proper function
	${test_fun_array[$(($arr_index))]}
}
