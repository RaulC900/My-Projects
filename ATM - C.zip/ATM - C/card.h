#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

Card* searchCard(LSC **l, char *id, int nr_sub);