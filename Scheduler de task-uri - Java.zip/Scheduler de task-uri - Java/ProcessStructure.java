package TemaPOO;

public class ProcessStructure {
	private String type;
	private int weight;
		    
	public ProcessStructure(String type, int weight) {
		this.type = type;
		this.weight = weight;
	}
		    
	public String getType() {
		return type;
	}
		    
	public int getWeight() {
		return weight;
	}

}
