package TemaPOO;

public class Square {
	
	public Square() {
		
	}
	
	/**
	 * Returns the square of a number
	 * @param nrprimit Number given as parameter
	 * @return Square of number
	 */
	
	public int squareOfNumber(int nrprimit) {
		return nrprimit*nrprimit;
	}
}