package TemaPOO;

public class Cube {
	
	public Cube() {
		
	}
	
	/**
	 * Returns the cube of a number
	 * @param nrprimit Number given as parameter
	 * @return Cube of the number
	 */
	
	public int cubeOfNumber(int nrprimit) {
		return nrprimit*nrprimit*nrprimit;
	}
}
