/* CREMENESCU RAUL-VALENTIN - 341C5 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include "List.h"

int ParseCmd(char *command, t_db **db);
